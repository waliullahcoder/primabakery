@extends('layouts.admin.create_app')

@section('content')
    <div class="row g-3">
        <div class="col-lg-4 col-sm-6">
            <label for="company_id" class="form-label"><b>Company Name</b></label>
            <select name="company_id" id="company_id" class="select form-select" data-placeholder="Select Company" required>
                <option value=""></option>
                @foreach ($companies as $company)
                    <option value="{{ $company->id }}"
                        {{ old('company_id') && old('company_id') == $company->id ? 'selected' : '' }}>{{ $company->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="parent_id" class="form-label"><b>Parent Category</b></label>
            <select name="parent_id" id="parent_id" class="select form-select" data-placeholder="Select Parent..">
                <option value=""></option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}"
                        {{ old('parent_id') && old('parent_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}
                    </option>
                    @foreach ($category->children as $child)
                        <option value="{{ $child->id }}"
                            {{ old('parent_id') && old('parent_id') == $child->id ? 'selected' : '' }}>{{ $child->name }}
                        </option>
                    @endforeach
                @endforeach
            </select>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="name" class="form-label"><b>Name</b></label>
            <input type="text" class="form-control" id="name" name="name" required placeholder="Category Name"
                value="{{ old('name') }}">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="image" class="form-label"><b>Image <span class="text-danger">(500x500)</span></b></label>
            <input type="file" id="image" name="image" required class="form-control" accept="image/*">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="vendor_id" class="form-label"><b>Vendor Names</b></label>
            <select name="vendor_id[]" id="vendor_id" class="select form-select" multiple
                data-placeholder="Select Vendors.." required>
                @foreach ($vendors as $vendor)
                    <option value="{{ $vendor->id }}"
                        {{ old('vendor_id') && in_array($vendor->id, old('vendor_id')) ? 'selected' : '' }}>
                        {{ $vendor->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label class="form-label text-white"><b></b></label>
            <div class="d-flex gap-3 align-items-center flex-wrap pt-2 mt-1">
                {{-- <div class="flex-shrink-0">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="featured" id="featured">
                        <label class="custom-control-label" for="featured">Featured</label>
                    </div>
                </div> --}}
                <div class="flex-shrink-0">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="status" checked id="status">
                        <label class="custom-control-label" for="status">Show</label>
                    </div>
                </div>
                <div class="flex-shrink-0">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="show_frontend" checked id="show_frontend">
                        <label class="custom-control-label" for="show_frontend">Show in Homepage</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <label for="meta_title" class="form-label"><b>Meta Title</b></label>
            <input type="text" class="form-control" id="meta_title" name="meta_title" placeholder="Meta Title"
                value="{{ old('meta_title') }}">
        </div>
        <div class="col-sm-6">
            <label for="meta_keyword" class="form-label"><b>Meta Keyword</b></label>
            <input type="text" class="form-control" id="meta_keyword" name="meta_keyword" placeholder="Meta Keyword"
                value="{{ old('meta_keyword') }}">
        </div>
        <div class="col-12">
            <label for="meta_description" class="form-label"><b>Meta Description</b></label>
            <textarea name="meta_description" id="meta_description" cols="30" rows="4" class="form-control"
                placeholder="Meta Description">{{ old('meta_description') }}</textarea>
        </div>
    </div>
@endsection
