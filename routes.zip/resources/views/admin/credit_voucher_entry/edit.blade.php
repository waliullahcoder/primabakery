@extends('layouts.admin.edit_app')

@section('content')
    <div class="row g-3">
        <div class="col-lg-4 col-sm-6">
            <label for="debit_head" class="form-label"><b>Debit Account Head</b></label>
            <select name="debit_head" id="debit_head" class="chosen-select" required data-placeholder="select Account Name">
                <option value="">Select Account Name</option>
                @foreach ($debitCoas as $item)
                    <option value="{{ $item->id }}" {{ $debitEntry->coa_setup_id == $item->id ? 'selected' : '' }}>
                        {{ $item->head_name }} - {{ $item->head_code }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="voucher_no" class="form-label"><b>Voucher No</b></label>
            <input type="text" class="form-control" name="voucher_no" id="voucher_no"
                value="{{ $debitEntry->voucher_no }}" required>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="voucher_date" class="form-label"><b>Transaction Date</b></label>
            <input type="text" class="form-control date_picker" name="voucher_date" id="voucher_date"
                value="{{ date('d-m-Y', strtotime(old('voucher_date') ?? $debitEntry->voucher_date)) }}"
                placeholder="Transaction Date" required>
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="credit_heads" class="form-label"><b>Debit Account Head</b></label>
            <select name="credit_heads" id="credit_heads" class="chosen-select" data-placeholder="select Debit Head">
                <option value="">Select Account Name</option>
                @foreach ($coas as $item)
                    <option value="{{ $item->id }}" data-name="{{ $item->head_name }}"
                        data-code="{{ $item->head_code }}">{{ $item->head_name }} -
                        {{ $item->head_code }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-8 col-sm-6">
            <label for="narration" class="form-label"><b>Remarks</b></label>
            <textarea class="form-control narration" id="narration" name="narration" rows="1" spellcheck="false"
                placeholder="Remarks">{{ $debitEntry->narration }}</textarea>
        </div>
        <div class="col-12">
            <button type="button" class="btn btn-xs btn-primary w-100 px-2 py-2" style="margin-top: 6px;"
                id="add_item">Add Account</button>
        </div>
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-bordered table-striped target-table align-middle mb-0">
                    <thead class="bg-primary border-primary text-white">
                        <tr>
                            <th class="py-1 text-center" width="50">SL#</th>
                            <th class="py-1 px-3">Account Name</th>
                            <th class="py-1 text-end" width="200">Debit</th>
                            <th class="py-1 text-center" width="100">Action</th>
                        </tr>
                    </thead>
                    <tbody id="tbody">
                        @foreach ($creditEntries as $item)
                            <tr>
                                <th class="py-1 text-center serial">{{ $loop->iteration }}</th>
                                <td class="py-1 px-3">
                                    <input type="hidden" name="coa_id[]" class="coa_id" value="{{ $item->coa_setup_id }}">
                                    <input type="hidden" name="head_code[{{ $item->coa_setup_id }}]" class="head_code"
                                        value="{{ @$item->coa->head_code }}">
                                    <b class="head_name">{{ @$item->coa->head_name }} - {{ @$item->coa->head_code }}</b>
                                </td>
                                <td class="py-1">
                                    <input type="number" class="credit text-end"
                                        name="credit_amount[{{ $item->coa_setup_id }}]" oninput="findTotal()"
                                        value="{{ $item->credit_amount }}">
                                </td>
                                <td class="py-1 text-center">
                                    <button type="button" class="btn btn-outline-danger btn-sm w-100 remove_btn">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot class="bg-primary text-white align-middle border-primary">
                        <tr>
                            <th colspan="2" class="py-1 text-end">Total Amount</th>
                            <td class="py-1">
                                <input type="number" step="any" class="totalCredit text-end border-transparent"
                                    id="totalCredit" name="totalCredit" value="{{ $creditEntries->sum('credit_amount') }}"
                                    readonly>
                            </td>
                            <th class="py-1"></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script type="text/javascript">
        $(document).ready(function() {
            $(".date_picker").datepicker({
                format: 'dd-mm-yyyy',
                changeMonth: true,
                changeYear: true,
            });

            $(document).on('click', '#add_item', function(e) {
                e.preventDefault();
                var head_id = $('#credit_heads').val();
                if (head_id == '') {
                    Swal.fire({
                        width: "22rem",
                        toast: true,
                        position: 'top-right',
                        text: "Please select a credit head!",
                        icon: "error",
                        showConfirmButton: false,
                        timer: 1500
                    });
                    return;
                }
                var head_name = $('#credit_heads option:selected').data('name');
                var head_code = $('#credit_heads option:selected').data('code');
                var count_rows = $('#tbody tr').length;
                var tr = `
                    <tr>
                        <th class="py-1 text-center serial">${count_rows+1}</th>
                        <td class="py-1 px-3">
                            <input type="hidden" name="coa_id[]" class="coa_id" value="${head_id}">
                            <input type="hidden" name="head_code[${head_id}]" class="head_code" value="${head_code}">
                            <b class="head_name">${head_name} - ${head_code}</b>
                        </td>
                        <td class="py-1">
                            <input type="number" class="credit text-end" name="credit_amount[${head_id}]" oninput="findTotal()"
                                value="0">
                        </td>
                        <td class="py-1 text-center">
                            <button type="button" class="btn btn-outline-danger btn-sm w-100 remove_btn">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                    </tr>`;
                $('#tbody').append(tr);
                $('#credit_heads option[value=' + head_id + ']').remove();
                $('#credit_heads').trigger("chosen:updated");
            });

            $(document).on('click', '.remove_btn', function(e) {
                e.preventDefault();
                $(this).closest('tr').remove();
                $('.serial').each(function(index, value) {
                    $(value).text(index + 1);
                });
                var coa_id = $(this).closest('tr').find('.coa_id').val();
                var head_name = $(this).closest('tr').find('.head_name').text();
                var head_code = $(this).closest('tr').find('.head_code').val();
                var option =
                    `<option value="${ coa_id }" data-name="${head_name}" data-code="${head_code}">${head_name} - ${head_code}</option>`;
                $('#credit_heads').append(option);
                $('#credit_heads').trigger("chosen:updated");
                findTotal();
            });
        });

        function findTotal() {
            var totalCredit = 0;
            var remarks = '';
            var loop = $('.row-count').val();
            $(".credit").each(function(index, value) {
                var credit = parseInt($(this).val());
                totalCredit += isNaN(credit) ? 0 : credit;
                var credit_head = $('.head_name')[index];
                var head_name = $(credit_head).text();
                var code = $('.head_code')[index];
                var head_code = $(code).val();
                if (remarks != '') {
                    remarks += ', ';
                }
                remarks += head_name;
            });
            $('#narration').val(remarks);
            $('#totalCredit').val(totalCredit);
        }
    </script>
@endpush
